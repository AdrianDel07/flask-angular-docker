import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BooksRoutingModule } from './books-routing.module';
import { BooksManagementComponent } from './containers/books-management/books-management.component';
import { TableComponent } from './components/table/table.component';
import { AddComponent } from './add/add.component';
import { MaterialModule } from 'src/app/shared/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [BooksManagementComponent, TableComponent, AddComponent],
  entryComponents: [AddComponent],
  imports: [
    CommonModule,
    BooksRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class BooksModule {}
