import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AddComponent } from '../../add/add.component';
import { Book } from '../../models/books.model';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.sass']
})
export class TableComponent implements OnInit {
  headElements = [
    { name: 'Title', size: 25 },
    { name: 'Author', size: 25 },
    { name: 'Read', size: 10 },
    { name: 'Action', size: 20 },
  ];

  books: Book[] = [
    {
      id: '1',
      title: 'On The Road'.toString(),
      author: 'Jack',
      read: true,
    },
    {
      id: '2',
      title: 'Harry Potter',
      author: 'J.K Rowling',
      read: false,
    },
  ];

  constructor(private readonly dialog: MatDialog) { }

  ngOnInit(): void {
  }

  onPressDelete(id: number): void {
    console.log(id)
  }

  onPressEdit(data: Book): void {
    this.dialog.open(AddComponent, {
      data
    });
  }

}
