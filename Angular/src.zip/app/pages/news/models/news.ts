export interface News {
  id: string | number;
  title: string;
  body: string;
}
