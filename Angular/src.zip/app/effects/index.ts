import { NewsEffects } from "../pages/news/store/news.effects";
​
export const effects: any[] = [NewsEffects];
